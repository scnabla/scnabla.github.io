$ErrorActionPreference = 'Stop'
. "$PSScriptRoot\env.ps1"
foreach ($name in @('outputs\index','outputs\qwen-customvoice','outputs\qwen-base','voices\index')) {
    New-Item -ItemType Directory -Force (Join-Path $TtsRoot $name) | Out-Null
}
foreach ($pair in @(@('outputs','outputs\index'), @('prompts','voices\index'))) {
    $link = "$TtsRoot\apps\index-tts\$($pair[0])"
    $target = Join-Path $TtsRoot $pair[1]
    if (!(Test-Path $link)) {New-Item -ItemType Junction -Path $link -Target $target | Out-Null}
    elseif ((Get-Item $link).LinkType -ne 'Junction') {throw "Existing non-junction directory: $link"}
}
$file = "$TtsRoot\apps\index-tts\indextts\infer_v2_5.py"
$content = [IO.File]::ReadAllText($file)
$old = "os.environ['HF_HUB_CACHE'] = './checkpoints/hf_cache'"
$new = "os.environ.setdefault('HF_HUB_CACHE', './checkpoints/hf_cache')"
if ($content.Contains($old)) {[IO.File]::WriteAllText($file, $content.Replace($old, $new), [Text.UTF8Encoding]::new($false))}
elseif (!$content.Contains($new)) {throw 'Index cache configuration changed; review required'}
$revisions = @{}
foreach ($app in @('qwen3-tts','index-tts')) {
    $rev = & git -C "$TtsRoot\apps\$app" rev-parse HEAD
    if ($LASTEXITCODE -ne 0) {throw 'Cannot read source revision'}
    $revisions[$app] = $rev
}
$revisions | ConvertTo-Json | Set-Content "$TtsRoot\logs\source-versions.json"
