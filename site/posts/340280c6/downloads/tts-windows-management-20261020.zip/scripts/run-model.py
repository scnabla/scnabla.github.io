"""使用独立环境启动本地配音服务，并保存配音结果。"""
import argparse
import atexit
import functools
import json
import msvcrt
import os
from pathlib import Path
import runpy
import socket
import sys
import threading
import time
import traceback
import uuid
import webbrowser
from datetime import datetime

ROOT = Path(__file__).resolve().parent.parent


class UserError(Exception):
    pass


def acquire_lock():
    handle = (ROOT / 'logs' / 'model.lock').open('a+b')
    handle.seek(0, 2)
    if handle.tell() == 0:
        handle.write(b'0')
        handle.flush()
    handle.seek(0)
    try:
        msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
    except OSError:
        handle.close()
        raise UserError('已有配音模型正在运行。请先在原运行窗口按 Ctrl+C 退出，再启动其他模型。') from None
    return handle


def wait_and_open(port):
    for _ in range(300):
        try:
            with socket.create_connection(('127.0.0.1', port), timeout=1):
                webbrowser.open(f'http://127.0.0.1:{port}')
                return
        except OSError:
            time.sleep(1)


class Tee:
    def __init__(self, stream, file):
        self.stream, self.file = stream, file

    def write(self, data):
        self.file.write(data)
        self.file.flush()
        return self.stream.write(data)

    def flush(self):
        self.file.flush()
        self.stream.flush()

    def __getattr__(self, name):
        return getattr(self.stream, name)


def save_qwen_outputs(kind):
    import soundfile as sf
    from qwen_tts import Qwen3TTSModel
    method_name = 'generate_custom_voice' if kind == 'customvoice' else 'generate_voice_clone'
    original = getattr(Qwen3TTSModel, method_name)
    destination = ROOT / 'outputs' / f'qwen-{kind}'
    destination.mkdir(parents=True, exist_ok=True)

    @functools.wraps(original)
    def wrapped(self, *args, **kwargs):
        wavs, sr = original(self, *args, **kwargs)
        stamp = datetime.now().strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:6]
        for i, wav in enumerate(wavs):
            path = destination / f'{stamp}-{i + 1}.wav'
            sf.write(path, wav, sr)
            print(f'配音已保存：{path}', flush=True)
        return wavs, sr

    setattr(Qwen3TTSModel, method_name, wrapped)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('model', choices=['customvoice', 'base', 'index'])
    parser.add_argument('--no-browser', action='store_true')
    args = parser.parse_args()
    lock = acquire_lock()
    atexit.register(lock.close)
    port = 7862 if args.model == 'index' else 7861
    try:
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', port))
    except OSError:
        raise UserError(f'端口 {port} 已被占用，配音服务未启动。请查看已有的运行窗口。') from None
    log = (ROOT / 'logs' / f'{args.model}-{datetime.now():%Y%m%d-%H%M%S}.log').open('a', encoding='utf-8', buffering=1)
    sys.stdout = Tee(sys.stdout, log)
    sys.stderr = Tee(sys.stderr, log)
    record = ROOT / 'logs' / f'process-{os.getpid()}.json'
    record.write_text(json.dumps({'pid': os.getpid(), 'executable': sys.executable, 'model': args.model, 'port': port, 'started': datetime.now().isoformat()}, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'正在加载模型。网页地址：http://127.0.0.1:{port}\n配音保存目录：{ROOT / "outputs"}\n退出服务请按 Ctrl+C。', flush=True)
    if not args.no_browser:
        threading.Thread(target=wait_and_open, args=(port,), daemon=True).start()
    import gradio as gr
    original_launch = gr.Blocks.launch

    @functools.wraps(original_launch)
    def launch_with_output_paths(self, *launch_args, **launch_kwargs):
        launch_kwargs['allowed_paths'] = [str(ROOT / 'voices'), str(ROOT / 'outputs')]
        return original_launch(self, *launch_args, **launch_kwargs)

    gr.Blocks.launch = launch_with_output_paths
    if args.model == 'index':
        app = ROOT / 'apps' / 'index-tts'
        os.chdir(app)
        sys.path.insert(0, str(app))
        sys.argv = ['webui.py', '--version', '2.5', '--model_dir', str(ROOT / 'models' / 'indextts-2.5'), '--fp16', '--host', '127.0.0.1', '--port', str(port), '--gui_seg_tokens', '80']
        runpy.run_path(str(app / 'webui.py'), run_name='__main__')
    else:
        os.chdir(ROOT / 'apps' / 'qwen3-tts')
        save_qwen_outputs(args.model)
        sys.argv = ['qwen-tts-demo', str(ROOT / 'models' / f'qwen-{args.model}'), '--device', 'cuda:0', '--dtype', 'bfloat16', '--no-flash-attn', '--concurrency', '1', '--ip', '127.0.0.1', '--port', str(port)]
        from qwen_tts.cli import demo
        original_mkstemp = demo.tempfile.mkstemp

        def voice_mkstemp(*args, **kwargs):
            if kwargs.get('prefix') == 'voice_clone_prompt_':
                kwargs['dir'] = str(ROOT / 'voices')
            return original_mkstemp(*args, **kwargs)

        demo.tempfile.mkstemp = voice_mkstemp
        demo.main()


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\n配音服务已停止。')
    except UserError as exc:
        print(str(exc))
        sys.exit(1)
    except Exception:
        traceback.print_exc()
        sys.exit(1)
