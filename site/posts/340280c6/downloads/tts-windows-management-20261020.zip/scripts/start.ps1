param([ValidateSet('customvoice','base','index')][string]$Model = 'customvoice', [switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
. "$PSScriptRoot\env.ps1"
$app = if ($Model -eq 'index') {'index-tts'} else {'qwen3-tts'}
$python = "$TtsRoot\apps\$app\.venv\Scripts\python.exe"
if (!(Test-Path $python)) {throw "Missing environment: $python"}
$arguments = @("$TtsRoot\scripts\run-model.py", $Model)
if ($NoBrowser) {$arguments += '--no-browser'}
& $python @arguments
exit $LASTEXITCODE
